
from django.conf.urls import url
from django.contrib import admin
from boxes import views
from app01 import views as a
urlpatterns = [
    url('admin/', admin.site.urls),
    #班级列表
    url('grade_list/',views.grade_list),
    #添加班级
    url('add_grade/',views.add_grade),
    #删除班级
    url('delete_grade/',views.delete_grade),
    #修改班级名称
    url('edit_grade/',views.edit_grade),
    #学生列表
    url('student_list/',views.student_list),
    #添加学生信息
    url('add_student/',views.add_student),
    #删除学生信息
    url('delete_student/',views.del_student),
    #修改学生信息
    url('edit_student/',views.edit_student),
    #老师列表
    url('teacher_list/',views.teacher_list),
    #添加老师信息
    url('add_teacher/',views.add_teacher),
    #删除老师信息
    url('delete_teacher/',views.delete_teacher),
    #修改老师信息
    url('edit_teacher/',views.edit_teacher),
    #上传文件
    url('upload/',a.upload),
    #登录
    # url('login/',b.login)
    #没有就返回班级信息
    # url(r'$',views.grade_list),





]
