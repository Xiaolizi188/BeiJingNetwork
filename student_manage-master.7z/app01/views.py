from django.shortcuts import render,HttpResponse

# Create your views here.



def upload(request):
    if request.method =='POST':
        file_obj=request.FILES.get('file_name')
        file_name=file_obj.name
        with open(file_name,'wb') as f:
            for line in file_obj:
                f.write(line)
        return HttpResponse('上传成功')
    return render(request,'upload.html')
