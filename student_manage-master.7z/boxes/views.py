from django.shortcuts import render,redirect,HttpResponse
from boxes import models
# Create your views here.
#班级管理函数
def grade_list(request):
    #取班级里所有的对象
    grades=models.Grades.objects.all()
    #班级管理页面
    return render(request,'grade_list.html',{'grade_list':grades})

#增加班级函数
def add_grade(request):
    #判断POST方法，是增加班级
    if request.method =='POST':
        #获取新输入的班级名字
        grade_name=request.POST.get('grade_name')
        #ORM存入数据
        models.Grades.objects.create(grade_name=grade_name)
        return redirect('/grade_list/')
    #进入增加班级页面
    return render(request,'add_grade.html')
#删除班级函数
def delete_grade(request):
    #获取要删除班级的id
    delete_grade_id=request.GET.get('id')
    #找到要删除的对象
    grade_obj=models.Grades.objects.get(id=delete_grade_id)
    #执行删除
    grade_obj.delete()
    #返回班级管理页面
    return redirect('/grade_list/')

#修改班级函数
def edit_grade(request):
    #判断方法'POST'就是在修改
    if request.method=='POST':
        #获取新的值
        new_grade_name=request.POST.get('grade_name')
        #获取修改的id值
        grade_id =request.POST.get('edit_id')
        #通过id获取对象
        grade=models.Grades.objects.get(id=grade_id)
        #给要修改的对象重新赋值
        grade.grade_name=new_grade_name
        #修改后保存
        grade.save()
        return  redirect('/grade_list/')
    #没修改，加载网页的数据，获取URL的
    edit_id= request.GET.get("id")
    #获取数据具体对象
    grade=models.Grades.objects.get(id=edit_id)
    #转到修改的页面
    return render(request,'edit_grade.html',{'grade':grade})

#学生管理函数
def student_list(request):
    #获取所有的学生对象
    students=models.Students.objects.all()

    return render(request,'student_list.html',{'student_list':students})

#增加学生函数
def add_student(request):
    if request.method=='POST':
        new_student_name=request.POST.get('student_name')
        new_grade_id=request.POST.get('grade_id')
        models.Students.objects.create(student_name=new_student_name,grade_id=new_grade_id)
        return redirect('/student_list/')

    new_grade_list=models.Grades.objects.all()
    new_student_list=models.Students.objects.all()
    return render(request,'add_student.html',{'student_list':new_student_list,'grade_list':new_grade_list})


#删除学生函数
def del_student(request):
    delete_id=request.GET.get('id')
    student_obj=models.Students.objects.get(id=delete_id)
    student_obj.delete()
    return redirect('/student_list/')


#修改学生函数
def edit_student(request):
    if request.method=='POST':
        new_student_name=request.POST.get('student_name')
        student_id=request.POST.get('edit_id')
        grade_id=request.POST.get('grade_id')
        student_obj=models.Students.objects.get(id=student_id)
        student_obj.student_name=new_student_name
        student_obj.grade_id=grade_id
        student_obj.save()
        return redirect('/student_list/')

    grades=models.Grades.objects.all()
    edit_student_id=request.GET.get('id')
    new_students=models.Students.objects.get(id=edit_student_id)
    return render(request,'edit_student.html',{'student':new_students,'grade_list':grades})
#老师列表函数
def teacher_list(request):

    teachers=models.Teachers.objects.all()
    return render(request,'teacher_list.html',{'teacher_list':teachers})

#添加老师信息函数
def add_teacher(request):
    if request.method=='POST':
        teacher_name=request.POST.get('teacher_name')
        models.Teachers.objects.create(teacher_name=teacher_name)
        return redirect('/teacher_list/')
    grades=models.Grades.objects.all()
    return render(request, 'add_teacher.html', {'grade_list':grades})

#删除老师信息
def delete_teacher(request):
    delete_teacher_id=request.GET.get('id')
    teacher_obj=models.Teachers.objects.get(id=delete_teacher_id)
    teacher_obj.delete()
    return redirect('/teacher_list/')

#修改老师信息
def edit_teacher(request):
    if request.method=='POST':
        new_teacher_name=request.POST.get('teacher_name')
        teacher_id=request.POST.get('teacher_id')
        edit_teacher_obj=models.Teachers.objects.get(id=teacher_id)

        new_grade_ids=request.POST.getlist('grade_ids')

        edit_teacher_obj.teacher_name=new_teacher_name

        edit_teacher_obj.save()

        edit_teacher_obj.grades.set(new_grade_ids)

        return redirect('/teacher_list/')

    grades = models.Grades.objects.all()
    teacher_id=request.GET.get('id')
    teacher=models.Teachers.objects.get(id=teacher_id)
    return render(request,'edit_teacher.html',{'teacher':teacher,'grade_list':grades})

# 查找学生信息
# def search_student(request):
#     search_id=request.GET.get('id')
#     student_obj=models.Students.objects.get(id=search_id)
#     student_obj.search()
#     return redirect('/student_list/')

# def find(request):
#     return render(request, 'find.html')
# 
# def find_(request):
#     return render(request, 'find_.html')
# 
# def finds(request):
#     name = request.POST.get('name')
#     a = models.objects.filter(name=name)
#     if a:
#         return render(request, 'finds.html', {'result': a})
#     else:
#         return HttpResponse('查无此人')
# 
# def find_s(request):
#     name = request.POST.get('name')
#     a = models.objects.objects.filter(name=name)
#     if a:
#         return render(request, 'find_s.html', {'result': a})
#     else:
#         return HttpResponse('查我此人')











