from django.db import models
# from django.contrib.auth.models import AbstractUser
# Create your models here.


#班级类
class Grades(models.Model):
    id =models.AutoField(primary_key=True)
    grade_name=models.CharField(max_length=32)


#学生类
class Students(models.Model):
    id=models.AutoField(primary_key=True)
    student_name=models.CharField(max_length=32)
    grade=models.ForeignKey(to=Grades,on_delete=True)   #外键关联


#老师类
class Teachers(models.Model):
    id =models.AutoField(primary_key=True)
    teacher_name=models.CharField(max_length=32)
    grades=models.ManyToManyField(to=Grades)  #多对多
# # 登录注册
# class User(AbstractUser):
#     nickname = models.CharField(max_length=50, blank=True)
#
#     class Meta(AbstractUser.Meta):
#         pass