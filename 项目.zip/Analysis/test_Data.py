# coding=utf-8

from pandas import DataFrame
import pandas as pd
import csv

# reader=pd.read_csv('NBA_Data.csv')
# print(reader.shape)
pd.set_option('display.max_columns', 1000)
pd.set_option('display.width', 1000)
pd.set_option('display.max_colwidth', 1000)
# 文件路径
srcFilePath = "NBA_Data.csv"
# 读取cvs格式的数据文件
reader = csv.reader(open(srcFilePath, 'r', encoding='UTF-8'))
# reader.rename(columns=['球员','赛季','果','比赛','首发','时间','投篮','命中','出手','三分','命中','出手','篮板','前场','后场','助攻','抢断','盖帽','失误','犯规','得分'])
# csv中各列属性代表的含义（1）代表第一列
# 球员姓名(1)、赛季(2)、胜负(3)、对手球队名称(4)、对手球队总得分（5）、己方球队总得分（6）
# 、己方球队名称（7）、首发（8）【1为首发，0为替补】、上场时间（9）、投篮命中率（10）、投篮命中数（11）
# 、投篮出手数（12）、三分命中率（13）、三分命中数（14）、三分出手数（15）、罚球命中率（16）
# 、罚球命中数（17）、罚球次数（18）、总篮板数（19）、前场篮板数（20）、后场篮板数（21）、助攻数（22）
# 、抢断数（23）、盖帽数（24）、失误数（25）、犯规数（26）、得分（27）
records = [line for line in reader]
# print(len(records))
frame = DataFrame(records)

# 获取得分数对应的场次数目
pts_count = frame[26].value_counts()
# print(pts_count)
a = []
b = []

for i in pts_count.keys():
    a.append(i)
for i in pts_count:
    b.append(i)
c = {}
for i in range(0, len(a)):
    c[int(a[i])] = int(b[i])
d = sorted(c.items(), key=lambda c: c[0])
# 存储得分分数
e = []
# 存储相应分数的次数
f = []
for i in d:
    e.append(i[0])
    f.append(i[1])
# 15-16赛季球员得分助攻篮板抢断盖帽平均值
# print(records)
i = 0
print(len(records[930]))
print(len(records[931]))
print(len(records[932]))
# print(records[931])
# print(records[932])
exit()
for line in records:
    print(i)
    if len(line) != 0 and line[1] == '06-07':
        print(line)
        print("*" * 50)
        print(line[26])
        print(line[21])
        print(line[18])
        print(line[22])
        print(line[23])
    i += 1

exit()
records_p4 = [(int(line[26]), int(line[21]), int(line[18]), int(line[22]), int(line[23])) for line in records if
              len(line) != 0 and line[1] == '06-07']
