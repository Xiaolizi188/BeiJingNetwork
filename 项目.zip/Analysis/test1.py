import pandas as pd
reader=pd.read_csv('NBA_Data.csv')
print(reader.head())