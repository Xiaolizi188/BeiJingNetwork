from django.shortcuts import render
from Analysis.data import get_data
def index(request):
    data_source = get_data()
    print(data_source)
    e, f, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, c11, c12, c13 ,c14,c15,s1, s2, s3, s4, s5, s6, s7, s8, s9, s10,s11, s12, s13, s14, s15 ,pitching , pitching_3,pitching_3_3,Seasonwinning,Failured = data_source
    return render(request, 'test_1.html', locals())
def index1(request):
    return render(request,'index1.html')
def what(request):
    return render(request,'what.html')