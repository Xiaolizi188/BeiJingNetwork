import requests,re,csv,urllib.request
#计数，初始化
count = 0
#以下定义的与之对应的是球员姓名、赛季、胜负、比赛、首发、时间、投篮命中率、投篮命中数、投篮出手数、三分命中率、三分命中数、三分出手数、罚球命中率、罚球命中数、罚球次数、总篮板数、前场篮板数、后场篮板数、助攻数、抢断数、盖帽数、失误数、犯规数、得分
list0 = []
list1 = []
list2 = []
list3 = []
list4 = []
list5 = []
list6 = []
list7 = []
list8 = []
list9 = []
list10 = []
list11 = []
list12 = []
list13 = []
list14 = []
list15 = []
list16 = []
list17 = []
list18 = []
list19 = []
list20 = []
list21 = []
list22 = []
list23 = []
list24 = []
list25 = []
list26 = []
#定义获取页面函数
# def getHtml(url):
#     page = urllib.request.urlopen(url)
#     html = page.read()
#     html = html.decode('utf-8')
#     print(html)
#     return html
print('玩命加载中...')
def GetHtml(url):
    page = requests.get(url)
    page.encoding='utf-8'
    html = page.text
    # print(html)
    return html
#获取数据并存入数据库中
for x in range(0,60):
    #获取当前页面，该页面只有LBJ的职业生涯常规赛的数据
    html = GetHtml("http://www.stat-nba.com/query.php?QueryType=game&GameType=season&Player_id=1862&crtcol=season"
                   "&order=1&page=" + str(x))
    # 获取球员姓名、赛季、胜负、比赛、首发、时间、投篮命中率、投篮命中数、投篮出手数、三分命中率、三分命中数、三分出手数、罚球命中率、罚球命中数、罚球次数、总篮板数、前场篮板数、后场篮板数、助攻数、抢断数、盖帽数、失误数、犯规数、得分
    #正则得到相对应的数值
    NBA = re.findall(r'<td class="normal player_name_out change_color col1 row.+"><a.*>(.*)</a></td>'
                            r'\s*<td class="current season change_color col2 row.+"><a.*>(.*)</a></td>'
                            r'\s*<td class="normal wl change_color col3 row.+">(.*)</td>'
                            r'\s*<td class="normal result_out change_color col4 row.+"><a.*>(\D*|76人)(\d+)-(\d+)(\D*)</a></td>'
                            r'\s*<td class="normal gs change_color col5 row.+">(.*)</td>'
                            r'\s*<td class="normal mp change_color col6 row.+">(.*)</td>'
                            r'\s*<td class="normal fgper change_color col7 row.+">(.*%|\s*)</td>'
                            r'\s*<td class="normal fg change_color col8 row.+">(.*)</td>'
                            r'\s*<td class="normal fga change_color col9 row.+">(.*)</td>'
                            r'\s*<td class="normal threepper change_color col10 row.+">(.*%|\s*)</td>'
                            r'\s*<td class="normal threep change_color col11 row.+">(.*)</td>'
                            r'\s*<td class="normal threepa change_color col12 row.+">(.*)</td>'
                            r'\s*<td class="normal ftper change_color col13 row.+">(.*%|\s*)</td>'
                            r'\s*<td class="normal ft change_color col14 row.+">(.*)</td>'
                            r'\s*<td class="normal fta change_color col15 row.+">(.*)</td>'
                            r'\s*<td class="normal trb change_color col16 row.+">(.*)</td>'
                            r'\s*<td class="normal orb change_color col17 row.+">(.*)</td>'
                            r'\s*<td class="normal drb change_color col18 row.+">(.*)</td>'
                            r'\s*<td class="normal ast change_color col19 row.+">(.*)</td>'
                            r'\s*<td class="normal stl change_color col20 row.+">(.*)</td>'
                            r'\s*<td class="normal blk change_color col21 row.+">(.*)</td>'
                            r'\s*<td class="normal tov change_color col22 row.+">(.*)</td>'
                            r'\s*<td class="normal pf change_color col23 row.+">(.*)</td>'
                            r'\s*<td class="normal pts change_color col24 row.+">(.*)</td>', html)
    #获取每条数据，
    for data in NBA:
        #元组数据复制给列表，进行修改，数据中有空值，和含有%号的值，进行处理，得到数值
        data1 = [data[0], data[1], data[2], data[3], int(data[4]), data[5], data[6], data[7], data[8], data[9],
                 data[10], data[11], data[12], data[13], data[14], data[15], data[16], data[17], data[18], data[19],
                 data[20], data[21], data[22], data[23], data[24], data[25], data[26]]
#将百分号去掉，只保留数值部分
        if (data1[15] == ' '):
            data1[15] = 0
        else:
            data1[15] = float("".join(re.findall(r'(.*)%', data1[15])))
        if (data1[9] == ' '):
            data1[9] = 0
        else:
            data1[9] = float("".join(re.findall(r'(.*)%', data1[9])))
        if (data1[12] == ' '):
            data1[12] = 0
        else:
            data1[12] = float("".join(re.findall(r'(.*)%', data1[12])))
        list0.append(data1[0])
        list1.append(data1[1])
        list2.append(data1[2])
        list3.append(data1[3])
        list4.append(data1[4])
        list5.append(data1[5])
        list6.append(data1[6])
        list7.append(data1[7])
        list8.append(data1[8])
        list9.append(data1[9])
        list10.append(data1[10])
        list11.append(data1[11])
        list12.append(data1[12])
        list13.append(data1[13])
        list14.append(data1[14])
        list15.append(data1[15])
        list16.append(data1[16])
        list17.append(data1[17])
        list18.append(data1[18])
        list19.append(data1[19])
        list20.append(data1[20])
        list21.append(data1[21])
        list22.append(data1[22])
        list23.append(data1[23])
        list24.append(data1[24])
        list25.append(data1[25])
        list26.append(data1[26])
        # 记录数据数量
        count += 1
#建立csv存储文件，wb写 a+追加模式
csvfile = open('NBA_Data.csv','w+',newline='',encoding='utf-8')
writer = csv.writer(csvfile)
# csvfile = file('nbadata.csv', 'ab+')
# writer = csv.writer(csvfile)
#将提取的数据合并
data2 = []
for i in range(0,count):
    data2.append((list0[i],list1[i],list2[i],list3[i],list4[i],list5[i],list6[i],list7[i],list8[i]
                  ,list9[i],list10[i],list11[i],list12[i],list13[i],list14[i],list15[i],list16[i]
                  ,list17[i],list18[i],list19[i],list20[i],list21[i],list22[i],list23[i],list24[i]
                  , list25[i],list26[i]))
print(data2)
#将合并的数据存入csv
writer.writerows(data2)
csvfile.close()
