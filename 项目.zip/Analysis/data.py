import os
import docx
from collections import Counter
from flask import Flask,render_template
from flask_bootstrap import Bootstrap
from pandas import DataFrame,Series
import pandas as pd
import numpy as np
import csv
from 项目.settings import BASE_DIR
def get_data():
    # reader=pd.read_csv('NBA_Data.csv')
    # print(reader.shape)
    pd.set_option('display.max_columns', 1000)
    pd.set_option('display.width', 1000)
    pd.set_option('display.max_colwidth', 1000)
    # 文件路径
    srcFilePath = os.path.join(BASE_DIR, "Analysis/NBA_Data.csv")
    # 读取cvs格式的数据文件
    reader = csv.reader(open(srcFilePath, 'r', encoding='UTF-8'))
    # reader.rename(columns=['球员','赛季','果','比赛','首发','时间','投篮','命中','出手','三分','命中','出手','篮板','前场','后场','助攻','抢断','盖帽','失误','犯规','得分'])
    # csv中各列属性代表的含义（1）代表第一列
    # 球员姓名(1)、赛季(2)、胜负(3)、对手球队名称(4)、对手球队总得分（5）、己方球队总得分（6）
    # 、己方球队名称（7）、首发（8）【1为首发，0为替补】、上场时间（9）、投篮命中率（10）、投篮命中数（11）
    # 、投篮出手数（12）、三分命中率（13）、三分命中数（14）、三分出手数（15）、罚球命中率（16）
    # 、罚球命中数（17）、罚球次数（18）、总篮板数（19）、前场篮板数（20）、后场篮板数（21）、助攻数（22）
    # 、抢断数（23）、盖帽数（24）、失误数（25）、犯规数（26）、得分（27）
    records = [line for line in reader]
    print(len(records))
    frame = DataFrame(records)
    print('\033[1;35;0m fram_start \033[0m')
    # print(frame)
    print('\033[1;35;0m fram_stop \033[0m')
    # 获取得分数对应的场次数目
    pts_count = frame[26].value_counts()
    # print(pts_count)
    a = []
    b = []

    for i in pts_count.keys():
        a.append(i)
    for i in pts_count:
        b.append(i)
    c = {}
    for i in range(0, len(a)):
        c[int(a[i])] = int(b[i])
    d = sorted(c.items(), key=lambda c: c[0])
    # print(a)
    # print(b)
    # print(c)
    # print(d)
    # 存储得分分数
    e = []
    # 存储相应分数的次数
    f = []
    for i in d:
        e.append(i[0])
        # print('\033[1;35;0m 得分分数开始打印 \033[0m')
        # print(e)
        # print('\033[1;35;0m 得分分数打印完毕 \033[0m')
        f.append(i[1])
        # print('\033[1;35;0m 相应分数的次数开始打印 \033[0m')
        # print(f)
        # print('\033[1;35;0m 相应分数的次数打印完毕 \033[0m')
        # print(f)
    # 15-16赛季球员得分助攻篮板抢断盖帽平均值
    # print(records)
    records_p1 = [(int(line[26]), int(line[21]), int(line[18]), int(line[22]), int(line[23])) for line in records if
                  len(
                      line) != 0 and line[1] == '03-04']
    # exit()
    records_p2 = [(int(line[26]), int(line[21]), int(line[18]), int(line[22]), int(line[23])) for line in records if
                  len(line) != 0 and line[1]
                  == '04-05']
    records_p3 = [(int(line[26]), int(line[21]), int(line[18]), int(line[22]), int(line[23])) for line in records if
                  len(
                      line) != 0 and len(line) == 27 and line[1] == '05-06']
    records_p4 = [(int(line[26]), int(line[21]), int(line[18]), int(line[22]), int(line[23])) for line in records if
                  len(
                      line) != 0 and len(line) == 27 and line[1] == '06-07']
    records_p5 = [(int(line[26]), int(line[21]), int(line[18]), int(line[22]), int(line[23])) for line in records if
                  len(line) != 0 and line[1] == '07-08']
    records_p6 = [(int(line[26]), int(line[21]), int(line[18]), int(line[22]), int(line[23])) for line in records if
                  len(line) != 0 and line[1] == '08-09']
    records_p7 = [(int(line[26]), int(line[21]), int(line[18]), int(line[22]), int(line[23])) for line in records if
                  line[1] == '09-10']
    records_p8 = [(int(line[26]), int(line[21]), int(line[18]), int(line[22]), int(line[23])) for line in records if
                  line[1] == '10-11']
    records_p9 = [(int(line[26]), int(line[21]), int(line[18]), int(line[22]), int(line[23])) for line in records if
                  line[1] == '11-12']
    records_p10 = [(int(line[26]), int(line[21]), int(line[18]), int(line[22]), int(line[23])) for line in records if
                   line[1] == '12-13']
    records_p11 = [(int(line[26]), int(line[21]), int(line[18]), int(line[22]), int(line[23])) for line in records if
                   line[1] == '13-14']
    records_p12 = [(int(line[26]), int(line[21]), int(line[18]), int(line[22]), int(line[23])) for line in records if
                   line[1] == '14-15']
    records_p13 = [(int(line[26]), int(line[21]), int(line[18]), int(line[22]), int(line[23])) for line in records if
                   line[1] == '15-16']
    records_p14 = [(int(line[26]), int(line[21]), int(line[18]), int(line[22]), int(line[23])) for line in records if
                   line[1] == '16-17']
    records_p15 = [(int(line[26]), int(line[21]), int(line[18]), int(line[22]), int(line[23])) for line in records if
                   line[1] == '17-18']
    shooting1 = [(float(line[9])) for line in records if line[1] =='03-04']
    shooting2 = [(float(line[9])) for line in records if line[1] =='04-05']
    shooting3 = [(float(line[9])) for line in records if line[1] == '05-06']
    shooting4 = [(float(line[9])) for line in records if line[1] == '06-07']
    shooting5 = [(float(line[9])) for line in records if line[1] == '07-08']
    shooting6 = [(float(line[9])) for line in records if line[1] == '08-09']
    shooting7 = [(float(line[9])) for line in records if line[1] == '09-10']
    shooting8 = [(float(line[9])) for line in records if line[1] == '10-11']
    shooting9 = [(float(line[9])) for line in records if line[1] == '11-12']
    shooting10 = [(float(line[9])) for line in records if line[1] == '12-13']
    shooting11 = [(float(line[9])) for line in records if line[1] == '13-14']
    shooting12 = [(float(line[9])) for line in records if line[1] == '14-15']
    shooting13 = [(float(line[9])) for line in records if line[1] == '15-16']
    shooting14 = [(float(line[9])) for line in records if line[1] == '16-17']
    shooting15 = [(float(line[9])) for line in records if line[1] == '17-18']
    shooting_1 = [(float(line[12])) for line in records if line[1] == '03-04']
    shooting_2 = [(float(line[12])) for line in records if line[1] == '04-05']
    shooting_3 = [(float(line[12])) for line in records if line[1] == '05-06']
    shooting_4 = [(float(line[12])) for line in records if line[1] == '06-07']
    shooting_5 = [(float(line[12])) for line in records if line[1] == '07-08']
    shooting_6 = [(float(line[12])) for line in records if line[1] == '08-09']
    shooting_7 = [(float(line[12])) for line in records if line[1] == '09-10']
    shooting_8 = [(float(line[12])) for line in records if line[1] == '10-11']
    shooting_9 = [(float(line[12])) for line in records if line[1] == '11-12']
    shooting_10 = [(float(line[12])) for line in records if line[1] == '12-13']
    shooting_11 = [(float(line[12])) for line in records if line[1] == '13-14']
    shooting_12 = [(float(line[12])) for line in records if line[1] == '14-15']
    shooting_13 = [(float(line[12])) for line in records if line[1] == '15-16']
    shooting_14 = [(float(line[12])) for line in records if line[1] == '16-17']
    shooting_15 = [(float(line[12])) for line in records if line[1] == '17-18']
    shooting3_1 = [(float(line[15])) for line in records if line[1] == '03-04']
    shooting3_2 = [(float(line[15])) for line in records if line[1] == '04-05']
    shooting3_3 = [(float(line[15])) for line in records if line[1] == '05-06']
    shooting3_4 = [(float(line[15])) for line in records if line[1] == '06-07']
    shooting3_5 = [(float(line[15])) for line in records if line[1] == '07-08']
    shooting3_6 = [(float(line[15])) for line in records if line[1] == '08-09']
    shooting3_7 = [(float(line[15])) for line in records if line[1] == '09-10']
    shooting3_8 = [(float(line[15])) for line in records if line[1] == '10-11']
    shooting3_9 = [(float(line[15])) for line in records if line[1] == '11-12']
    shooting3_10 = [(float(line[15])) for line in records if line[1] == '12-13']
    shooting3_11 = [(float(line[15])) for line in records if line[1] == '13-14']
    shooting3_12 = [(float(line[15])) for line in records if line[1] == '14-15']
    shooting3_13 = [(float(line[15])) for line in records if line[1] == '15-16']
    shooting3_14 = [(float(line[15])) for line in records if line[1] == '16-17']
    shooting3_15 = [(float(line[15])) for line in records if line[1] == '17-18']
    win1 = [(str(line[2])) for line in records if line[1] == '03-04']
    win2 = [(str(line[2])) for line in records if line[1] == '04-05']
    win3 = [(str(line[2])) for line in records if line[1] == '05-06']
    win4 = [(str(line[2])) for line in records if line[1] == '06-07']
    win5 = [(str(line[2])) for line in records if line[1] == '07-08']
    win6 = [(str(line[2])) for line in records if line[1] == '08-09']
    win7 = [(str(line[2])) for line in records if line[1] == '09-10']
    win8 = [(str(line[2])) for line in records if line[1] == '10-11']
    win9 = [(str(line[2])) for line in records if line[1] == '11-12']
    win10 = [(str(line[2])) for line in records if line[1] == '12-13']
    win11 = [(str(line[2])) for line in records if line[1] == '13-14']
    win12 = [(str(line[2])) for line in records if line[1] == '14-15']
    win13 = [(str(line[2])) for line in records if line[1] == '15-16']
    win14 = [(str(line[2])) for line in records if line[1] == '16-17']
    win15 = [(str(line[2])) for line in records if line[1] == '17-18']
    print('03-04赛季胜场:',Counter(win1).get('胜'),'赛季总场:',len(win1),
          '04-05赛季胜场:',Counter(win2).get('胜'),'赛季总场:',len(win2),
          '05-06赛季胜场:', Counter(win3).get('胜'),'赛季总场:',len(win3),
          '06-07赛季胜场:', Counter(win4).get('胜'),'赛季总场:',len(win4),
          '07-08赛季胜场:', Counter(win5).get('胜'),'赛季总场:',len(win5),
          '08-09赛季胜场:', Counter(win6).get('胜'),'赛季总场:',len(win6),
          '09-10赛季胜场:', Counter(win7).get('胜'),'赛季总场:',len(win7),
          '10-11赛季胜场:', Counter(win8).get('胜'),'赛季总场:',len(win8),
          '11-12赛季胜场:', Counter(win9).get('胜'),'赛季总场:',len(win9),
          '12-13赛季胜场:', Counter(win10).get('胜'),'赛季总场:',len(win10),
          '13-14赛季胜场:', Counter(win11).get('胜'),'赛季总场:',len(win11),
          '14-15赛季胜场:', Counter(win12).get('胜'),'赛季总场:',len(win12),
          '15-16赛季胜场:', Counter(win13).get('胜'),'赛季总场:',len(win13),
          '16-17赛季胜场:', Counter(win14).get('胜'),'赛季总场:',len(win14),
          '17-18赛季胜场:', Counter(win15).get('胜'),'赛季总场:',len(win15),)
    print('03-04赛季负场:',Counter(win1).get('负'),'赛季总场:',len(win1),
          '04-05赛季负场:',Counter(win2).get('负'),'赛季总场:',len(win2),
          '05-06赛季负场:', Counter(win3).get('负'),'赛季总场:',len(win3),
          '06-07赛季负场:', Counter(win4).get('负'),'赛季总场:',len(win4),
          '07-08赛季负场:', Counter(win5).get('负'),'赛季总场:',len(win5),
          '08-09赛季负场:', Counter(win6).get('负'),'赛季总场:',len(win6),
          '09-10赛季负场:', Counter(win7).get('负'),'赛季总场:',len(win7),
          '10-11赛季负场:', Counter(win8).get('负'),'赛季总场:',len(win8),
          '11-12赛季负场:', Counter(win9).get('负'),'赛季总场:',len(win9),
          '12-13赛季负场:', Counter(win10).get('负'),'赛季总场:',len(win10),
          '13-14赛季负场:', Counter(win11).get('负'),'赛季总场:',len(win11),
          '14-15赛季负场:', Counter(win12).get('负'),'赛季总场:',len(win12),
          '15-16赛季负场:', Counter(win13).get('负'),'赛季总场:',len(win13),
          '16-17赛季负场:', Counter(win14).get('负'),'赛季总场:',len(win14),
          '17-18赛季负场:', Counter(win15).get('负'),'赛季总场:',len(win15),)
    Seasonwinning = [
        round(Counter(win1).get('胜') / len(win1) * 100,2),
        round(Counter(win2).get('胜') / len(win2) * 100,2),
        round(Counter(win3).get('胜') / len(win3) * 100, 2),
        round(Counter(win4).get('胜') / len(win4) * 100, 2),
        round(Counter(win5).get('胜') / len(win5) * 100, 2),
        round(Counter(win6).get('胜') / len(win6) * 100, 2),
        round(Counter(win7).get('胜') / len(win7) * 100, 2),
        round(Counter(win8).get('胜') / len(win8) * 100, 2),
        round(Counter(win9).get('胜') / len(win9) * 100, 2),
        round(Counter(win10).get('胜') / len(win10) * 100, 2),
        round(Counter(win11).get('胜') / len(win11) * 100, 2),
        round(Counter(win12).get('胜') / len(win12) * 100, 2),
        round(Counter(win13).get('胜') / len(win13) * 100, 2),
        round(Counter(win14).get('胜') / len(win14) * 100, 2),
        round(Counter(win15).get('胜') / len(win15) * 100, 2),
    ]
    Failured = [
        round(Counter(win1).get('负') / len(win1) * 100, 2),
        round(Counter(win2).get('负') / len(win2) * 100, 2),
        round(Counter(win3).get('负') / len(win3) * 100, 2),
        round(Counter(win4).get('负') / len(win4) * 100, 2),
        round(Counter(win5).get('负') / len(win5) * 100, 2),
        round(Counter(win6).get('负') / len(win6) * 100, 2),
        round(Counter(win7).get('负') / len(win7) * 100, 2),
        round(Counter(win8).get('负') / len(win8) * 100, 2),
        round(Counter(win9).get('负') / len(win9) * 100, 2),
        round(Counter(win10).get('负') / len(win10) * 100, 2),
        round(Counter(win11).get('负') / len(win11) * 100, 2),
        round(Counter(win12).get('负') / len(win12) * 100, 2),
        round(Counter(win13).get('负') / len(win13) * 100, 2),
        round(Counter(win14).get('负') / len(win14) * 100, 2),
        round(Counter(win15).get('负') / len(win15) * 100, 2),
    ]
    print(Failured)
    print("*" * 20 + " ok !!!" + "*" * 20)
    g1 = [float('%0.1f' % i) for i in DataFrame(records_p1).mean()]
    g2 = [float('%0.1f' % i) for i in DataFrame(records_p2).mean()]
    g3 = [float('%0.1f' % i) for i in DataFrame(records_p3).mean()]
    g4 = [float('%0.1f' % i) for i in DataFrame(records_p4).mean()]
    g5 = [float('%0.1f' % i) for i in DataFrame(records_p5).mean()]
    g6 = [float('%0.1f' % i) for i in DataFrame(records_p6).mean()]
    g7 = [float('%0.1f' % i) for i in DataFrame(records_p7).mean()]
    g8 = [float('%0.1f' % i) for i in DataFrame(records_p8).mean()]
    g9 = [float('%0.1f' % i) for i in DataFrame(records_p9).mean()]
    g10 = [float('%0.1f' % i) for i in DataFrame(records_p10).mean()]
    g11 = [float('%0.1f' % i) for i in DataFrame(records_p11).mean()]
    g12 = [float('%0.1f' % i) for i in DataFrame(records_p12).mean()]
    g13 = [float('%0.1f' % i) for i in DataFrame(records_p13).mean()]
    g14 = [float('%0.1f' % i) for i in DataFrame(records_p14).mean()]
    g15 = [float('%0.1f' % i) for i in DataFrame(records_p15).mean()]
    k1 =  [float('%0.1f' % i) for i in DataFrame(shooting1).sum() / len(shooting1)]
    k2 = [float('%0.1f' % i) for i in DataFrame(shooting2).sum() / len(shooting2)]
    k3 = [float('%0.1f' % i) for i in DataFrame(shooting3).sum() / len(shooting3)]
    k4 = [float('%0.1f' % i) for i in DataFrame(shooting4).sum() / len(shooting4)]
    k5 = [float('%0.1f' % i) for i in DataFrame(shooting5).sum() / len(shooting5)]
    k6 = [float('%0.1f' % i) for i in DataFrame(shooting6).sum() / len(shooting6)]
    k7 = [float('%0.1f' % i) for i in DataFrame(shooting7).sum() / len(shooting7)]
    k8 = [float('%0.1f' % i) for i in DataFrame(shooting8).sum() / len(shooting8)]
    k9 = [float('%0.1f' % i) for i in DataFrame(shooting9).sum() / len(shooting9)]
    k10 = [float('%0.1f' % i) for i in DataFrame(shooting10).sum() / len(shooting10)]
    k11 = [float('%0.1f' % i) for i in DataFrame(shooting11).sum() / len(shooting11)]
    k12 = [float('%0.1f' % i) for i in DataFrame(shooting12).sum() / len(shooting12)]
    k13 = [float('%0.1f' % i) for i in DataFrame(shooting13).sum() / len(shooting13)]
    k14 = [float('%0.1f' % i) for i in DataFrame(shooting14).sum() / len(shooting14)]
    k15 = [float('%0.1f' % i) for i in DataFrame(shooting15).sum() / len(shooting15)]
    s1 = [float('%0.1f' % i) for i in DataFrame(shooting_1).sum() / len(shooting_1)]
    s2 = [float('%0.1f' % i) for i in DataFrame(shooting_2).sum() / len(shooting_2)]
    s3 = [float('%0.1f' % i) for i in DataFrame(shooting_3).sum() / len(shooting_3)]
    s4 = [float('%0.1f' % i) for i in DataFrame(shooting_4).sum() / len(shooting_4)]
    s5 = [float('%0.1f' % i) for i in DataFrame(shooting_5).sum() / len(shooting_5)]
    s6 = [float('%0.1f' % i) for i in DataFrame(shooting_6).sum() / len(shooting_6)]
    s7 = [float('%0.1f' % i) for i in DataFrame(shooting_7).sum() / len(shooting_7)]
    s8 = [float('%0.1f' % i) for i in DataFrame(shooting_8).sum() / len(shooting_8)]
    s9 = [float('%0.1f' % i) for i in DataFrame(shooting_9).sum() / len(shooting_9)]
    s10 = [float('%0.1f' % i) for i in DataFrame(shooting_10).sum() / len(shooting_10)]
    s11 = [float('%0.1f' % i) for i in DataFrame(shooting_11).sum() / len(shooting_11)]
    s12 = [float('%0.1f' % i) for i in DataFrame(shooting_12).sum() / len(shooting_12)]
    s13 = [float('%0.1f' % i) for i in DataFrame(shooting_13).sum() / len(shooting_13)]
    s14 = [float('%0.1f' % i) for i in DataFrame(shooting_14).sum() / len(shooting_14)]
    s15 = [float('%0.1f' % i) for i in DataFrame(shooting_15).sum() / len(shooting_15)]
    f1 = [float('%0.1f' % i) for i in DataFrame(shooting3_1).sum() / len(shooting_1)]
    f2 = [float('%0.1f' % i) for i in DataFrame(shooting3_2).sum() / len(shooting_2)]
    f3 = [float('%0.1f' % i) for i in DataFrame(shooting3_3).sum() / len(shooting_3)]
    f4 = [float('%0.1f' % i) for i in DataFrame(shooting3_4).sum() / len(shooting_4)]
    f5 = [float('%0.1f' % i) for i in DataFrame(shooting3_5).sum() / len(shooting_5)]
    f6 = [float('%0.1f' % i) for i in DataFrame(shooting3_6).sum() / len(shooting_6)]
    f7 = [float('%0.1f' % i) for i in DataFrame(shooting3_7).sum() / len(shooting_7)]
    f8 = [float('%0.1f' % i) for i in DataFrame(shooting3_8).sum() / len(shooting_8)]
    f9 = [float('%0.1f' % i) for i in DataFrame(shooting3_9).sum() / len(shooting_9)]
    f10 = [float('%0.1f' % i) for i in DataFrame(shooting3_10).sum() / len(shooting_10)]
    f11 = [float('%0.1f' % i) for i in DataFrame(shooting3_11).sum() / len(shooting_11)]
    f12 = [float('%0.1f' % i) for i in DataFrame(shooting3_12).sum() / len(shooting_12)]
    f13 = [float('%0.1f' % i) for i in DataFrame(shooting3_13).sum() / len(shooting_13)]
    f14 = [float('%0.1f' % i) for i in DataFrame(shooting3_14).sum() / len(shooting_14)]
    f15 = [float('%0.1f' % i) for i in DataFrame(shooting3_15).sum() / len(shooting_15)]
    # print(f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13,f14,f15)
    # print(s1)
    # print(g1, g2, g3, g4, g5, g6, g7, g8, g9, g10, g11, g12, g13)
    # print(k1,k2,k3,k4,k5,k6,k7,k8,k9,k10,k11,k12,k13,k14,k15)
    # print(Seasonwinning)
    # print(win1)
    # # print(len(win))
    # a=[]
    # for i in win1:
    #     if i =='胜':
    #         # print(i)
    #         a.append(i)
    # # print(len(a))
    # win1_1 = (len(a)/len(win1)*100)
    # print(win1_1)
    # print(shooting_1,shooting_2,shooting_3,shooting_4,shooting_5,shooting_6,shooting_7,shooting_8,shooting_9,
    #       shooting_10,shooting_11,shooting_12,shooting_13,shooting_14,shooting_15)
    pitching = k1+k2+k3+k4+k5+k6+k7+k8+k9+k10+k11+k12+k13+k14+k15
    pitching_3 = s1+s2+s3+s4+s5+s6+s7+s8+s9+s10+s11+s12+s13+s14+s15
    pitching_3_3 = f1+f2+f3+f4+f5+f6+f7+f8+f9+f10+f11+f12+f13+f14+f15
    # print(pitching_3_3)
    # print(pitching)
    # print(s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12, s13, s14, s15)
    # document = docx.Document('../Analysis/分析.docx')
    # docText = '\n\n'.join([
    #     paragraph.text.encode('utf-8') for paragraph in document.paragraphs
    # ])
    # print(docText)
    print("*" * 20 + "its ok !!!" + "*" * 20)
    return e,f,g1,g2,g3,g4,g5,g6,g7,g8,g9,g10,g11,g12,g13,g14,g15,s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12,\
           s13, s14, s15,pitching,pitching_3,pitching_3_3,Seasonwinning,Failured
#Analysis = Flask(__name__)
#引入bootstrap前端框架
#bootstrap = Bootstrap(Analysis)
#@Analysis.route('/',methods=('POST','GET'))
#def index():
#    return render_template('index.html', a=e, b=f, c1=g1,c2=g2,c3=g3,c4=g4,c5=g5,c6=g6,c7=g7,c8=g8,c9=g9,c10=g10,
# c11=g11,c12=g12,c13=g13)
    # return render_template('index.html',a=e)

if __name__ == '__main__':
    data = get_data()
    print(data)
