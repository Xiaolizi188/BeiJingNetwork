from django.contrib import admin
from django.urls import path
from Analysis.views import index,index1,what
urlpatterns = [
    path('',index1),
    path('index/',index,name='index'),
    path('Analysis report/',what,name='what')

]
